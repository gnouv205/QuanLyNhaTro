Dự án 1 
Giảng viên hướng dẫn thực hiện: Phan Viết Thế
Thành viên: 
PS37749 - Cao Quốc Thịnh
PS40131 - Trần Quốc Trương
PS41294 - Trương Thanh Bạch
PS41292 - Nguyễn Đình Vương
PS29673 - Trần Minh Sang

Ở đây chúng tôi tạo 1 dự án Quản lý phòng trọ bằng ngôn ngữ C# Winform.
