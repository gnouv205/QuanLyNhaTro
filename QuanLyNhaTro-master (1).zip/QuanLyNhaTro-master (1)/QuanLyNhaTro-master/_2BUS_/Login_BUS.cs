﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using _1DAL_;
using DTO;

namespace _2BUS_
{
    public static class Login_BUS
    {
        public static bool NhanVienlogin(NguoiDung_DTO nhanvien)
        {
            return Login_DAL.NhanVienLogin(nhanvien);
        }
            // ma hoa
        public static string encryption(string pass)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] encryption;
            UTF8Encoding uTF8 = new UTF8Encoding();
            encryption = md5.ComputeHash(uTF8.GetBytes(pass));
            StringBuilder encryptiondata = new StringBuilder();
            for (int i = 0; i < encryption.Length; i++)
            {
                encryptiondata.Append(encryption[i].ToString());
            }
            return encryptiondata.ToString();
        }
       
    }
}
