﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _1DAL_;
using DTO;

namespace _2BUS_
{
    public static class ChangePass_BUS
    {
        public static bool CapNhatMatKhau(string email, string oldpass, string newpass)
        {
            return ChangePass_DAL.CapNhatMatKhau(email, oldpass, newpass);
        }
    }
}
