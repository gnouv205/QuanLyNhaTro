﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using _1DAL_;
using DTO;

namespace _2BUS_
{
    public static class Forget_BUS
    {
        public static bool ForgetPass(string email)
        {
            return ForgetPass_DAL.ForgetPass(email);
        }
        public static string RandomString(int size, bool LowerCase)
        {
            StringBuilder buider = new StringBuilder();
            Random rand = new Random();
            char kytu;
            for (int i = 0; i < size; i++)
            {
                kytu = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * rand.NextDouble() + 65)));
                buider.Append(kytu);
            }
            if (LowerCase)
                return buider.ToString().ToLower();
            return buider.ToString();
        }

        public static int RandomNumber(int min, int max)
        {
            Random rand = new Random();
            return rand.Next(min, max);
        }

        public static void SendMail(string email, string matkhau)
        {
            try
            {
                SmtpClient client = new SmtpClient("smtp.gmail.com", 25);

                NetworkCredential cred = new NetworkCredential("sender@gmail", "chonduoi");

                MailMessage msg = new MailMessage();

                msg.From = new MailAddress("sender@gmail.com");

                msg.To.Add(email);

                msg.Subject = "Bạn Đã Sử Dụng Quên Mật Khẩu";

                msg.Body = "Chào anh/chị. Mật Khẩu Mới Truy Cập Phâng Mềm Là: " + matkhau;

                client.Credentials = cred;

                client.EnableSsl = true;

                client.Send(msg);
          
            }
            catch(Exception ex)
            {
                string result = ex.Message;
            }
        }

        public static void CreateNewPass(string email, string newpass)
        {
             ForgetPass_DAL.CreateNewPass(email, newpass);
        }
    }
}
