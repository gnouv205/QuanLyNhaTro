﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;

namespace _1DAL_
{
    public class ForgetPass_DAL
    {
        public static bool ForgetPass(string email)
        {
            using (SqlConnection con = DataAccess.connect())
            using (SqlCommand cmd = new SqlCommand("SP_QuenMatKhau", con)) 
            { 
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@email", email);

                if (Convert.ToInt16(cmd.ExecuteScalar()) > 0)
                    return true;
            }
                return false;
        }

        public static void CreateNewPass(string email, string newpass)
        {
            string query = "update Nguoidung set MatKhau = @newpass where email  = @email";
            using (SqlConnection con = DataAccess.connect())
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                con.Open();
                cmd.Parameters.AddWithValue("@newpass", newpass);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }
}
