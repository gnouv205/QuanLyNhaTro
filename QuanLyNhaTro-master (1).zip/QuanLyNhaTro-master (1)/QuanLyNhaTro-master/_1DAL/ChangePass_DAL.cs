﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using System.Data.SqlClient;
using System.Data;

namespace _1DAL_
{
    public static class ChangePass_DAL
    {
        public static bool CapNhatMatKhau(string email, string oldpass, string newpass)
        {
            using (SqlConnection con = DataAccess.connect())

            using (SqlCommand cmd = new SqlCommand("SP_DoiMatKhau", con))
            { 
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@oldpass", oldpass);
                cmd.Parameters.AddWithValue("@newpass", newpass);

                if (cmd.ExecuteNonQuery() > 0)
                    return true;
            }
            return false;
        }
    }
}
