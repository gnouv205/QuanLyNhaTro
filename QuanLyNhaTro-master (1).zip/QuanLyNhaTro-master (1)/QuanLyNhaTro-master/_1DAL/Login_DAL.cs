﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using System.Data.SqlClient;
using System.Data;

namespace _1DAL_
{
    public static class Login_DAL
    {
        public static bool NhanVienLogin(NguoiDung_DTO nguoidung)
        {
            using (SqlConnection con = DataAccess.connect())
            using (SqlCommand cmd = new SqlCommand("SP_DangNhap ", con))
            {
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@email", nguoidung.Email);
                cmd.Parameters.AddWithValue("@Pass", nguoidung.MatKhau);

                if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                    return true;
            }
            return false;
        }     
    }
}

