﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _1DAL_
{
    public  class DataAccess
    {
        public static SqlConnection connect()
        {
             SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-NU0C2IOG\SQLEXPRESS;Initial Catalog=QuanLyNhaTro;Integrated Security=True");
            return con;
        }

    }
}
