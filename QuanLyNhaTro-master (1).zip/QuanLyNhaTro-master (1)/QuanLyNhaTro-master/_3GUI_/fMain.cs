﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DTO;
using _2BUS_;
using System.IO;

namespace _3GUI_
{
    public partial class fMain : Form
    {
        public static int session = 1; // load form
        public static int profile = 0;
        public static string email;
        public fMain()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }

        #region checkForm
        private bool CheckForm(Form form)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (frm.Name == form.Name)
                {
                    return true;
                }
            }
            return false;
        }
        private void ActiveChilForm(Form form)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (frm.Name == form.Name)
                {
                    frm.Activate();
                }
            }
        }

        private void OpenForm(Form form)
        {
            if (!CheckForm(form))
            {
                form.MdiParent = this;
                form.Show();
            }
            else
            {
                ActiveChilForm(form);
            }
            form.FormClosed += Form_FormClosed;
        }

        private void Form_FormClosed(object sender, FormClosedEventArgs e)
        {
            fMain_Load(sender, e);
        }

        #endregion

        #region Even
        private void đăngNhậpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new fLogin());
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            fMain_Load(sender, e);
        }

        private void Nv_FormClosed(object sender, FormClosedEventArgs e)
        {
            fMain_Load(sender, e);
        }
        private void ĐổiMatkhauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenForm(new fChangePass());
        }
        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            session = 1;
            fMain_Load(sender, e);
        }
        private void hướngDẫnSửDụngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                var path = Path.Combine(Directory.GetCurrentDirectory(), "Tai lieu su dung phan mem");
                if (Directory.Exists(path))
                {
                    System.Diagnostics.Process.Start(path);
                }
                else
                {
                    MessageBox.Show("Thư mục không tồn tại.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("khong ton tai", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void fMain_Load(object sender, EventArgs e)
        {
            if (profile == 1)
            {
                toolStripMenuItem1.Text = null;
                profile = 0;
            }
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        #endregion

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
