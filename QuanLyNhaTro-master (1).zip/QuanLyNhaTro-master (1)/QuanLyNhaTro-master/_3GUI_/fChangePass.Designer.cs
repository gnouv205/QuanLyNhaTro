﻿
namespace _3GUI_
{
    partial class fChangePass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new System.Windows.Forms.Panel();
            txtNhapLai = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            txtMatKhauMoi = new System.Windows.Forms.TextBox();
            label3 = new System.Windows.Forms.Label();
            txtMatKhauCu = new System.Windows.Forms.TextBox();
            lable2 = new System.Windows.Forms.Label();
            txtEmailNhanVien = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            panel2 = new System.Windows.Forms.Panel();
            btnExit = new System.Windows.Forms.Button();
            btnChangePass = new System.Windows.Forms.Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackgroundImage = Properties.Resources.mau_hong_didongviet_14;
            panel1.Controls.Add(txtNhapLai);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(txtMatKhauMoi);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(txtMatKhauCu);
            panel1.Controls.Add(lable2);
            panel1.Controls.Add(txtEmailNhanVien);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new System.Drawing.Point(1, 1);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(452, 306);
            panel1.TabIndex = 0;
            // 
            // txtNhapLai
            // 
            txtNhapLai.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            txtNhapLai.Location = new System.Drawing.Point(38, 263);
            txtNhapLai.Name = "txtNhapLai";
            txtNhapLai.Size = new System.Drawing.Size(379, 25);
            txtNhapLai.TabIndex = 4;
            txtNhapLai.UseSystemPasswordChar = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = System.Drawing.Color.HotPink;
            label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(38, 245);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(141, 15);
            label5.TabIndex = 7;
            label5.Text = "Nhập Lại Mật Khẩu Mới:";
            // 
            // txtMatKhauMoi
            // 
            txtMatKhauMoi.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            txtMatKhauMoi.Location = new System.Drawing.Point(38, 200);
            txtMatKhauMoi.Name = "txtMatKhauMoi";
            txtMatKhauMoi.Size = new System.Drawing.Size(379, 25);
            txtMatKhauMoi.TabIndex = 3;
            txtMatKhauMoi.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = System.Drawing.Color.HotPink;
            label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(38, 182);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(89, 15);
            label3.TabIndex = 5;
            label3.Text = "Mật Khẩu Mới:";
            // 
            // txtMatKhauCu
            // 
            txtMatKhauCu.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            txtMatKhauCu.Location = new System.Drawing.Point(38, 141);
            txtMatKhauCu.Name = "txtMatKhauCu";
            txtMatKhauCu.Size = new System.Drawing.Size(379, 25);
            txtMatKhauCu.TabIndex = 2;
            txtMatKhauCu.UseSystemPasswordChar = true;
            // 
            // lable2
            // 
            lable2.AutoSize = true;
            lable2.BackColor = System.Drawing.Color.HotPink;
            lable2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lable2.Location = new System.Drawing.Point(38, 123);
            lable2.Name = "lable2";
            lable2.Size = new System.Drawing.Size(83, 15);
            lable2.TabIndex = 3;
            lable2.Text = "Mật Khẩu Cũ:";
            // 
            // txtEmailNhanVien
            // 
            txtEmailNhanVien.Font = new System.Drawing.Font("Arial Unicode MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            txtEmailNhanVien.Location = new System.Drawing.Point(38, 83);
            txtEmailNhanVien.Name = "txtEmailNhanVien";
            txtEmailNhanVien.Size = new System.Drawing.Size(379, 28);
            txtEmailNhanVien.TabIndex = 1;
            txtEmailNhanVien.Text = "Nhap Email Cua Ban";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = System.Drawing.Color.HotPink;
            label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(38, 65);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(103, 15);
            label2.TabIndex = 1;
            label2.Text = "Email Nhân Viên:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.HotPink;
            label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(100, 8);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(261, 36);
            label1.TabIndex = 0;
            label1.Text = "ĐỔI MẬT KHẨU";
            // 
            // panel2
            // 
            panel2.BackgroundImage = Properties.Resources.mau_hong_didongviet_14;
            panel2.Controls.Add(btnExit);
            panel2.Controls.Add(btnChangePass);
            panel2.Location = new System.Drawing.Point(1, 313);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(452, 93);
            panel2.TabIndex = 1;
            // 
            // btnExit
            // 
            btnExit.BackColor = System.Drawing.Color.Firebrick;
            btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            btnExit.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            btnExit.Location = new System.Drawing.Point(62, 49);
            btnExit.Name = "btnExit";
            btnExit.Size = new System.Drawing.Size(329, 40);
            btnExit.TabIndex = 6;
            btnExit.Text = "Thoát";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnChangePass
            // 
            btnChangePass.BackColor = System.Drawing.Color.Firebrick;
            btnChangePass.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            btnChangePass.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnChangePass.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            btnChangePass.Location = new System.Drawing.Point(62, 3);
            btnChangePass.Name = "btnChangePass";
            btnChangePass.Size = new System.Drawing.Size(329, 40);
            btnChangePass.TabIndex = 5;
            btnChangePass.Text = "Đổi Mật Khẩu";
            btnChangePass.UseVisualStyleBackColor = false;
            btnChangePass.Click += btnChangePass_Click;
            // 
            // fChangePass
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.mau_hong_didongviet_14;
            ClientSize = new System.Drawing.Size(452, 408);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            Name = "fChangePass";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Đổi Mật Khẩu Nhân Viên";
            Load += fChangePass_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtNhapLai;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMatKhauMoi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMatKhauCu;
        private System.Windows.Forms.Label lable2;
        private System.Windows.Forms.TextBox txtEmailNhanVien;
        private System.Windows.Forms.Button btnChangePass;
        private System.Windows.Forms.Button btnExit;
    }
}