﻿
namespace _3GUI_
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new System.Windows.Forms.MenuStrip();
            hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            đăngNhậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ĐổiMatkhauToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            hướngDẫnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            hướngDẫnSửDụngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            giớiThiệuPhầnMềmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            label1 = new System.Windows.Forms.Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = System.Drawing.Color.Transparent;
            menuStrip1.BackgroundImage = Properties.Resources.acfa945879265145d45f94d16e36f11d;
            menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            menuStrip1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { hệThốngToolStripMenuItem, hướngDẫnToolStripMenuItem, toolStripMenuItem1 });
            menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            menuStrip1.Location = new System.Drawing.Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            menuStrip1.Size = new System.Drawing.Size(991, 27);
            menuStrip1.TabIndex = 4;
            // 
            // hệThốngToolStripMenuItem
            // 
            hệThốngToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { đăngNhậpToolStripMenuItem, đăngXuấtToolStripMenuItem, ĐổiMatkhauToolStripMenuItem, thoátToolStripMenuItem });
            hệThốngToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            hệThốngToolStripMenuItem.Size = new System.Drawing.Size(87, 23);
            hệThốngToolStripMenuItem.Text = "Hệ Thống";
            // 
            // đăngNhậpToolStripMenuItem
            // 
            đăngNhậpToolStripMenuItem.Name = "đăngNhậpToolStripMenuItem";
            đăngNhậpToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D;
            đăngNhậpToolStripMenuItem.Size = new System.Drawing.Size(231, 24);
            đăngNhậpToolStripMenuItem.Text = "Đăng Nhập";
            đăngNhậpToolStripMenuItem.Click += đăngNhậpToolStripMenuItem_Click;
            // 
            // đăngXuấtToolStripMenuItem
            // 
            đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            đăngXuấtToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X;
            đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(231, 24);
            đăngXuấtToolStripMenuItem.Text = "Đăng Xuất";
            đăngXuấtToolStripMenuItem.Click += đăngXuấtToolStripMenuItem_Click;
            // 
            // ĐổiMatkhauToolStripMenuItem
            // 
            ĐổiMatkhauToolStripMenuItem.Name = "ĐổiMatkhauToolStripMenuItem";
            ĐổiMatkhauToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H;
            ĐổiMatkhauToolStripMenuItem.Size = new System.Drawing.Size(231, 24);
            ĐổiMatkhauToolStripMenuItem.Text = "Đổi Mật Khẩu";
            ĐổiMatkhauToolStripMenuItem.Click += ĐổiMatkhauToolStripMenuItem_Click;
            // 
            // thoátToolStripMenuItem
            // 
            thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            thoátToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4;
            thoátToolStripMenuItem.Size = new System.Drawing.Size(231, 24);
            thoátToolStripMenuItem.Text = "Thoát";
            thoátToolStripMenuItem.Click += thoátToolStripMenuItem_Click;
            // 
            // hướngDẫnToolStripMenuItem
            // 
            hướngDẫnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { hướngDẫnSửDụngToolStripMenuItem, giớiThiệuPhầnMềmToolStripMenuItem });
            hướngDẫnToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            hướngDẫnToolStripMenuItem.Name = "hướngDẫnToolStripMenuItem";
            hướngDẫnToolStripMenuItem.Size = new System.Drawing.Size(100, 23);
            hướngDẫnToolStripMenuItem.Text = "Hướng Dẫn";
            // 
            // hướngDẫnSửDụngToolStripMenuItem
            // 
            hướngDẫnSửDụngToolStripMenuItem.Name = "hướngDẫnSửDụngToolStripMenuItem";
            hướngDẫnSửDụngToolStripMenuItem.Size = new System.Drawing.Size(226, 24);
            hướngDẫnSửDụngToolStripMenuItem.Text = "Hướng Dẫn Sử Dụng";
            hướngDẫnSửDụngToolStripMenuItem.Click += hướngDẫnSửDụngToolStripMenuItem_Click;
            // 
            // giớiThiệuPhầnMềmToolStripMenuItem
            // 
            giớiThiệuPhầnMềmToolStripMenuItem.Name = "giớiThiệuPhầnMềmToolStripMenuItem";
            giớiThiệuPhầnMềmToolStripMenuItem.Size = new System.Drawing.Size(226, 24);
            giớiThiệuPhầnMềmToolStripMenuItem.Text = "Giới Thiệu Phần Mềm";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            toolStripMenuItem1.RightToLeftAutoMirrorImage = true;
            toolStripMenuItem1.Size = new System.Drawing.Size(91, 23);
            toolStripMenuItem1.Text = "thongtinnv";
            toolStripMenuItem1.Visible = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.Transparent;
            label1.Font = new System.Drawing.Font("Times New Roman", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Orchid;
            label1.Image = Properties.Resources.acfa945879265145d45f94d16e36f11d;
            label1.Location = new System.Drawing.Point(176, 59);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(591, 45);
            label1.TabIndex = 5;
            label1.Text = "DỰ ÁN 1 - QUẢN LÝ NHÀ TRỌ";
            label1.Click += label1_Click;
            // 
            // fMain
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.acfa945879265145d45f94d16e36f11d;
            BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            ClientSize = new System.Drawing.Size(991, 520);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            DoubleBuffered = true;
            Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            Name = "fMain";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "fMain";
            Load += fMain_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngNhậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ĐổiMatkhauToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hướngDẫnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hướngDẫnSửDụngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giớiThiệuPhầnMềmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Label label1;
    }
}