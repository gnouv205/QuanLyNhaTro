﻿
namespace _3GUI_
{
    partial class fLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button button1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fLogin));
            panel1 = new System.Windows.Forms.Panel();
            lbForgetPass = new System.Windows.Forms.Label();
            cbSave = new System.Windows.Forms.CheckBox();
            txtPass = new System.Windows.Forms.TextBox();
            label3 = new System.Windows.Forms.Label();
            txtEmail = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            panel4 = new System.Windows.Forms.Panel();
            btnExit = new System.Windows.Forms.Button();
            btnLogin = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            pictureBox3 = new System.Windows.Forms.PictureBox();
            button1 = new System.Windows.Forms.Button();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            button1.BackgroundImage = (System.Drawing.Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            button1.CausesValidation = false;
            button1.Cursor = System.Windows.Forms.Cursors.AppStarting;
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button1.ForeColor = System.Drawing.SystemColors.ControlText;
            button1.Image = (System.Drawing.Image)resources.GetObject("button1.Image");
            button1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            button1.Location = new System.Drawing.Point(307, 299);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(359, 44);
            button1.TabIndex = 8;
            button1.Text = "Login Goolge";
            button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = System.Drawing.Color.Transparent;
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(lbForgetPass);
            panel1.Controls.Add(cbSave);
            panel1.Controls.Add(txtPass);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(label2);
            panel1.Location = new System.Drawing.Point(298, 93);
            panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(376, 155);
            panel1.TabIndex = 4;
            // 
            // lbForgetPass
            // 
            lbForgetPass.AutoSize = true;
            lbForgetPass.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lbForgetPass.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            lbForgetPass.Location = new System.Drawing.Point(258, 133);
            lbForgetPass.Name = "lbForgetPass";
            lbForgetPass.Size = new System.Drawing.Size(112, 16);
            lbForgetPass.TabIndex = 5;
            lbForgetPass.Text = "Quên Mật Khẩu ??";
            lbForgetPass.Click += lbForgetPass_Click;
            // 
            // cbSave
            // 
            cbSave.AutoSize = true;
            cbSave.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            cbSave.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            cbSave.Location = new System.Drawing.Point(9, 133);
            cbSave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            cbSave.Name = "cbSave";
            cbSave.Size = new System.Drawing.Size(133, 20);
            cbSave.TabIndex = 4;
            cbSave.Text = "Gợi Nhớ Mật Khẩu";
            cbSave.UseVisualStyleBackColor = true;
            cbSave.CheckedChanged += cbSave_CheckedChanged;
            // 
            // txtPass
            // 
            txtPass.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            txtPass.Location = new System.Drawing.Point(41, 89);
            txtPass.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            txtPass.Name = "txtPass";
            txtPass.Size = new System.Drawing.Size(329, 29);
            txtPass.TabIndex = 3;
            txtPass.Text = "2005";
            txtPass.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            label3.Location = new System.Drawing.Point(9, 59);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(49, 21);
            label3.TabIndex = 2;
            label3.Text = "Pass:";
            // 
            // txtEmail
            // 
            txtEmail.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            txtEmail.Location = new System.Drawing.Point(41, 25);
            txtEmail.Margin = new System.Windows.Forms.Padding(2, 5, 2, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new System.Drawing.Size(329, 29);
            txtEmail.TabIndex = 1;
            txtEmail.Text = "vuongttps@gmail.com";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            label2.Location = new System.Drawing.Point(9, 2);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(145, 21);
            label2.TabIndex = 0;
            label2.Text = "Email Đăng Nhập:";
            // 
            // panel4
            // 
            panel4.BackColor = System.Drawing.Color.Transparent;
            panel4.Controls.Add(btnExit);
            panel4.Controls.Add(btnLogin);
            panel4.Location = new System.Drawing.Point(298, 252);
            panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            panel4.Name = "panel4";
            panel4.Size = new System.Drawing.Size(376, 42);
            panel4.TabIndex = 7;
            // 
            // btnExit
            // 
            btnExit.AutoSize = true;
            btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            btnExit.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            btnExit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            btnExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnExit.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btnExit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            btnExit.Location = new System.Drawing.Point(191, 2);
            btnExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            btnExit.Name = "btnExit";
            btnExit.Size = new System.Drawing.Size(177, 39);
            btnExit.TabIndex = 1;
            btnExit.Text = "THOÁT";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnLogin
            // 
            btnLogin.AutoSize = true;
            btnLogin.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            btnLogin.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            btnLogin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            btnLogin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnLogin.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btnLogin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            btnLogin.Location = new System.Drawing.Point(10, 2);
            btnLogin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new System.Drawing.Size(178, 39);
            btnLogin.TabIndex = 0;
            btnLogin.Text = "ĐĂNG NHẬP";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.Transparent;
            label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Navy;
            label1.Location = new System.Drawing.Point(308, 9);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(119, 36);
            label1.TabIndex = 6;
            label1.Text = "LOGIN";
            label1.Click += label1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = System.Drawing.Color.Transparent;
            label4.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.Indigo;
            label4.Location = new System.Drawing.Point(307, 44);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(321, 31);
            label4.TabIndex = 9;
            label4.Text = " Quản Lý Nhà Trọ VN 2024";
            label4.Click += label4_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = System.Drawing.Color.Transparent;
            label6.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label6.ForeColor = System.Drawing.Color.Red;
            label6.Location = new System.Drawing.Point(421, 9);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(84, 36);
            label6.TabIndex = 11;
            label6.Text = "APP ";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.Color.Transparent;
            pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new System.Drawing.Point(0, 28);
            pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(301, 315);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = Properties.Resources._3001758;
            pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            pictureBox2.Image = Properties.Resources._3001758;
            pictureBox2.Location = new System.Drawing.Point(3, 27);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(34, 27);
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImage = Properties.Resources.password_icon_protection_illustration_sign_security_symbol_or_logo_vector;
            pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            pictureBox3.Location = new System.Drawing.Point(3, 89);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new System.Drawing.Size(34, 27);
            pictureBox3.TabIndex = 7;
            pictureBox3.TabStop = false;
            // 
            // fLogin
            // 
            AcceptButton = btnLogin;
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.White;
            BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            ClientSize = new System.Drawing.Size(680, 357);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(button1);
            Controls.Add(panel1);
            Controls.Add(panel4);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            DoubleBuffered = true;
            Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            MaximizeBox = false;
            Name = "fLogin";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Đăng Nhập Hệ Thống";
            Load += fLogin_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbForgetPass;
        private System.Windows.Forms.CheckBox cbSave;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}