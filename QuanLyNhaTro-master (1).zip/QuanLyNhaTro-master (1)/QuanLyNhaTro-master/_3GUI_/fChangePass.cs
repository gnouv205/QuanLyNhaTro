﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _2BUS_;
using DTO;

namespace _3GUI_
{
    public partial class fChangePass : Form
    {
        public fChangePass()
        {
            InitializeComponent();
        }

        NguoiDung_DTO nhanvien = new NguoiDung_DTO();
        bool KiemTraDauVao()
        {
            if (txtMatKhauCu.Text.Trim().Length == 0 || txtMatKhauMoi.Text.Trim().Length == 0 || txtNhapLai.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin.", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txtMatKhauCu.Focus();
                return false;
            }
            if (txtMatKhauMoi.Text != txtNhapLai.Text)
            {
                MessageBox.Show("Mật khẩu nhập lại không trùng khớp.", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txtMatKhauCu.Focus();
                return false;
            }
            return true;
        }

        void DoiMatKhau()
        {
            if (!KiemTraDauVao())
                return;

            nhanvien.Email = txtEmailNhanVien.Text;
            string matkhaucu = Login_BUS.encryption(txtMatKhauCu.Text);
            string matkhaumoi = Login_BUS.encryption(txtMatKhauMoi.Text);

            if (ChangePass_BUS.CapNhatMatKhau(txtEmailNhanVien.Text, matkhaucu, matkhaumoi))
            {
                fMain.profile = 1;
                fMain.session = 0;
                Forget_BUS.SendMail(txtEmailNhanVien.Text, matkhaumoi);
                MessageBox.Show("Cập Nhật Mật Khẩu Thành Công! Bạn Cần Đăng Nhập Lại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                fMain.session = 1;
                this.Close();
            }
            else
            {
                MessageBox.Show("thể thay đổi mật khẩu thất bại!! kiểm tra lại Email hoặc mật khẩu", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnChangePass_Click(object sender, EventArgs e)
        {
            DoiMatKhau();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fChangePass_Load(object sender, EventArgs e)
        {

        }
    }
}
