﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _2BUS_;
using DTO;

namespace _3GUI_
{
    public partial class fLogin : Form
    {
        public static string vaitro { get; set; }
        public static string matkhau { get; set; }

        NguoiDung_DTO nhanvien = new NguoiDung_DTO();
        public fLogin()
        {
            InitializeComponent();
        }

        bool KiemTraDauVao()
        {
            if (txtEmail.Text.Trim().Length == 0 || txtPass.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn vui long nhập Email và Mật Khẩu ", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtEmail.Focus();
                return false;
            }
            return true;
        }

        // kiểm tra đăng nhâp với tham số truyền vào 
        void KiemTraDangNhap(string email, string pass)
        {
            nhanvien.Email = email;
            nhanvien.MatKhau = Login_BUS.encryption(pass);

            if (Login_BUS.NhanVienlogin(nhanvien))
            {
                MessageBox.Show("Đăng Nhập  thành Công! ", "Caption", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                fMain.email = nhanvien.Email;
                fMain.session = 0;
                this.Close();
            }
            else
            {
                MessageBox.Show("Đăng Nhập Không thành Công! Kiểm Tra Lại Email Hoặc PassWord!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // cung cấp 1 mật khẩu ngẫu nhiên khi Click vào quên mật khẩu
        void TaoMatKhauNgauNhien()
        {
            if (Forget_BUS.ForgetPass(txtEmail.Text))
            {
                StringBuilder builder = new StringBuilder();
                builder.Append(Forget_BUS.RandomString(4, true));
                builder.Append(Forget_BUS.RandomNumber(1000, 9999));
                builder.Append(Forget_BUS.RandomString(2, false));
                MessageBox.Show(builder.ToString());
                string NewPass = Login_BUS.encryption(builder.ToString());
                Forget_BUS.CreateNewPass(txtEmail.Text, NewPass);// update đến sql
                Forget_BUS.SendMail(txtEmail.Text, builder.ToString());
            }
            else
            {
                MessageBox.Show("Email không tồn tại, vui lòng nhập lại Email");
            }
        }

        void Login()
        {
            if (!KiemTraDauVao())
                return;
            KiemTraDangNhap(txtEmail.Text, txtPass.Text);

        }

        void ForgetPass()
        {
            if (txtEmail.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn vui long nhập Email! ", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtEmail.Focus();
                return;
            }
            TaoMatKhauNgauNhien();
        }

        #region Even

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Login();
        }
        private void lbForgetPass_Click(object sender, EventArgs e)
        {
            ForgetPass();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn Có Muốn Thoát Chương Trình??", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                this.Close();
            }
        }
        #endregion

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cbSave_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void fLogin_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
