﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class NguoiDung_DTO
    {
        #region OBJECT
        private int id;
        public int Id { get => id; set => id = value; }

        private string maND;
        public string MaND { get => maND; set => maND = value; }

        private string tenND;
        public string TenND { get => tenND; set => tenND = value; }

        private string email;
        public string Email { get => email; set => email = value; }

        private string soDT;
        public string SoDT { get => soDT; set => soDT = value; }

        private string diaChi;
        public string DiaChi { get => diaChi; set => diaChi = value; }

        private string matKhau;
        public string MatKhau { get => matKhau; set => matKhau = value; }
        #endregion

        public NguoiDung_DTO(int id, string maND, string tenND, string email, string soDT, string diaChi, string matKhau)
        {
            this.Id = id;
            this.MaND = maND;
            this.TenND = tenND;
            this.Email = email;
            this.SoDT = soDT;
            this.DiaChi = diaChi;
            this.MatKhau = matKhau;
        }

        public NguoiDung_DTO() { }
    }
}
